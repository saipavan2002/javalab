package prg4;
import java.util.ArrayList;

public class users {
	String username , password;
	static private ArrayList<users> authusers = new ArrayList<users>();
	
	boolean authenticate(String username , String password) {
		authorizedUsers();
		for(users u : authusers) {
			if(u.username.equals(username) && u.password.equals(password))
				return true;
		}
		return false;	
	}	
	
	private void authorizedUsers() {
		users u = new users();
		u.username = "yash";
		u.password = "1234";
		authusers.add(u);
	}
}