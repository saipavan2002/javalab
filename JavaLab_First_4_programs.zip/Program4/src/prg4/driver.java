package prg4;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class driver extends JFrame{

	static JFrame frame;
	static JPanel panel;
	static GridBagConstraints gbc;
	static JButton additm , total , nxtCust;
	static driver d;
	static JTextArea tArea;
	static JScrollPane scroll;
	customer cust, currentCus;
	users user;
	item items;
	double amount;
	
	public driver() {
		cust = new customer();
		items = new item();
		user = new users();
		initializeGUI();
	}

	void initializeGUI() {
		frame = new JFrame("Customer GUI");
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		gbc = new GridBagConstraints();
		amount = 0;
	}

	boolean checkUser() {
		String username = JOptionPane.showInputDialog("Enter Username").trim();
		String password = JOptionPane.showInputDialog("Enter Password");
		
		if(user.authenticate(username, password)) {
			JOptionPane.showMessageDialog(null, "Successfully Logged In.");
			return false;
		} else {
			JOptionPane.showMessageDialog(null, "Incorrect Login Details! Please retry.");
			return true;
		}
	}
	
	void accessCust() {
		String cusid = JOptionPane.showInputDialog("Enter Customer ID").trim();
		currentCus = cust.validateCustId(cusid);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1;
		gbc.insets = new Insets(3,3,3,3);
		
		gbc.gridy = 0;
		gbc.gridx = 0;
		panel.add(new JLabel("Customer Id : "+currentCus.id,JLabel.CENTER), gbc);
		gbc.gridx = 1;
		panel.add(new JLabel("Customer Name : "+currentCus.name,JLabel.CENTER), gbc);
		gbc.gridx = 2;
		panel.add(new JLabel("Customer Mobile : "+currentCus.mobile,JLabel.CENTER), gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 3;
		String header[] = new String[] {"Item id" , "Item Name" , "Price" , "Quantity" , "Total" };
		DefaultTableModel dtm = new DefaultTableModel(header, 0);
		JTable tbl = new JTable(dtm);
		scroll = new JScrollPane(tbl, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setPreferredSize(new Dimension(0,200));
		panel.add(scroll , gbc);
		
		gbc.gridwidth = 1;
		gbc.gridy = 2;
		gbc.gridx = 2;
		JLabel total = new JLabel("Total : $0" , JLabel.CENTER);
		panel.add(total , gbc);

		gbc.gridy = 3;
		additm = new JButton("Add Item");
		additm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String id = JOptionPane.showInputDialog("Enter Item ID");
				item i = items.retrieveItem(id);
				int qty = Integer.parseInt(JOptionPane.showInputDialog("Enter the Qty"));
				dtm.addRow(new Object[] {i.id , i.name , i.price , qty ,  (qty*i.price) });
				amount += qty*i.price;
				total.setText("Total : $" + amount );
			}
		});

		gbc.gridx = 0;
		panel.add(additm, gbc);
		nxtCust = new JButton("Next Customer");
		nxtCust.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "Amount to be collected : $" + amount);
				frame.dispose();
				initializeGUI();
				d.accessCust();
			}
		});

		gbc.gridx = 2;
		panel.add(nxtCust, gbc);
		frame.add(panel , BorderLayout.CENTER);
		frame.setSize(700, 700);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		d = new driver();
		while(d.checkUser());
		d.accessCust();
	}
}