package prg4;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class customer {
	String name, id, mobile;
	static private ArrayList<customer> cust = new ArrayList<customer>();
	
	customer validateCustId(String id) {
		for(customer c : cust)
			if(c.id.equals(id))
				return c;

		customer c = new customer();
		c.name = JOptionPane.showInputDialog("Enter customer name");
		c.mobile = JOptionPane.showInputDialog("Enter customer mobile number");
		c.id = id;
		cust.add(c);
		return c;
	}
}