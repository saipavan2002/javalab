package prg4;
import java.util.*;
import javax.swing.JOptionPane;

public class item {
	String name , id;
	float price;
	
	static private ArrayList<item> itms = new ArrayList<item>();
	
	item retrieveItem(String id) {
		for(item i : itms)
			if(i.id.equals(id))
				return i;
		
		item i = new item();
		i.id = id;
		i.name = JOptionPane.showInputDialog("Enter product name").trim();
		i.price = Float.parseFloat(JOptionPane.showInputDialog("Enter price"));
		itms.add(i);
		return i;
	}	
}